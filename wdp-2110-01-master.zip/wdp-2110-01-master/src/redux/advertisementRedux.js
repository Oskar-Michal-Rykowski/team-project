/* selectors */
export const getAll = ({ advertisement }) => advertisement;

/* reducer */
export default function reducer(statePart = [], action = {}) {
  switch (action.type) {
    default:
      return statePart;
  }
}
