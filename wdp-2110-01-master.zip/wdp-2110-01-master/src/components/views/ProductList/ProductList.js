import React from 'react';
// import PropTypes from 'prop-types';
import styles from './ProductList.module.scss';

const ProductList = () => <div className={styles.root}>This is ProductList</div>;

// ProductList.propTypes = {};

export default ProductList;
