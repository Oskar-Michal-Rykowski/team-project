import React from 'react';
// import PropTypes from 'prop-types';
import styles from './ProductPage.module.scss';

const ProductPage = () => <div className={styles.root}>This is ProductPage</div>;

// ProductPage.propTypes = {};

export default ProductPage;
